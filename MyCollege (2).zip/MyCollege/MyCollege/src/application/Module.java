package application;


//File name :module.java
//* Author :MIcheal Agbenla
//* Description of class :info about students
	
public class Module {
	private String name;
	private String studentNumber;
	private int entryYear;
	private int studentAmount;
	private String programmeCode;
	
	//main constructor
	public Module() {
		this.name = " ";
		this.studentNumber = " ";
		this.entryYear = 0;
		this.programmeCode = " ";
	}
	
	//parameter constructor
	
	public Module(String n, String sN, String eY, int sA, int pC) {
		this.name = "n";
		this.studentNumber = "sN";
		this.entryYear = entryYear;
		this.studentAmount = studentAmount;
		this.programmeCode = "pC";
	}
	
	//getters and setter
	
	public String getName() {
		return this.name;
	}
	
	public String getStudentNumber() {
		return this.studentNumber;
	}
	
	public int getEntryYear() {
		return this.entryYear;
	}
	
	public String getProgrammeCode() {
		return this.programmeCode;
	}
	
	public int getStudentAmount() {
		return this.studentAmount;
	}
	
	public void setName(String n) {
		this.name = n;
	}
	
	public void setStudentNumber(String sN) {
		this.studentNumber = sN;
	}
	
	public void setEntryYear(int eY) {
		this.entryYear = eY;
	}
	
	public void setStudentAmount(int sA) {
		this.studentAmount = sA;
	}
	
	public void setProgrammeCode(String pC) {
		this.programmeCode = pC;
	}
	
	public String toString() {
		return "The amount of students is " + this.studentAmount + "\n"
				+ "The student number is " + this.studentNumber + "\n"
				+ "The student name is " + this.name + "\n"
				+ "The students year of entry" + this.entryYear + "\n"
				+ "The students programme code" + this.programmeCode + "\n";
	}




}
