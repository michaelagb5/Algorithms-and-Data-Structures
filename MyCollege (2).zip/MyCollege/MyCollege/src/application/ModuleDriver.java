package application;

//File name :moduleDriver.java
//* Author :MIcheal Agbenla
//* Description of class :sets what happens to each operation

import java.util.Scanner;

import dataStructures.LinkedList;


public class ModuleDriver {
	
	LinkedList<Module> list;
	
	public ModuleDriver()
	{
		Scanner scan = new Scanner(System.in);
		list = new LinkedList<Module>();
		
		inputModules();
		displayModules();
		
		scan.nextLine();
		removeFirstModule();
		displayModules();
	}
	public void inputModules()
	{
		Module p;
		String name, studentNumber, programmeCode;
		int entryYear, studentAmount;
		
		Scanner scan = new Scanner (System.in);
		for (int count=1; count <=10; count++)
        {
			System.out.println("How many students do you want to input");
			studentAmount = scan.nextInt();
	            while(studentAmount >= 11) {
	            	System.out.println("The number must be 10 or less");
            System.out.print("\nEnter students name " + count + " : ");
            name = scan.nextLine();
          
            System.out.print("Enter the students number " + count + " : ");
            studentNumber = scan.nextLine();
            	while(studentNumber != "TU" + int) {
            		System.out.println("Error");
            	}
            System.out.print("Enter number of credits for module " + count + " : ");
            programmeCode = scan.nextLine();
            System.out.println("Enter year of student's entry" + count + ":"); 
            entryYear= scan.nextInt();
            scan.nextLine();
            
            
            }

            
           p = new Module (name, studentNumber, programmeCode, entryYear, studentAmount);

            
            list.add(p);
        }
	}
	public void displayModules()
    {
        System.out.println("\nDisplaying all modules....");
       
        System.out.println(list.toString());       
    }

    public void removeFirstModule()
    {
    	System.out.println("\nRemoving the first element in the list...");
    	Module m = list.remove();
    	System.out.println("\n" + m.getName() + " has been deleted");
    }
    
    
    public static void main(String[] args)
    {
        new ModuleDriver();
    }
}
