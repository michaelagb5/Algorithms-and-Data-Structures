package dataStructures;

import dataStructures.LinearNode;

public class LinkedList<T> implements LinkedListADT<T> {
	
	 private int count;  
	 private LinearNode<T> front; 
	 private LinearNode<T> last; 
	 
	 
	    public LinkedList()
	    {
	       this.count = 0;
	       this.last = null;
	       this.front = null;
	    }

	    
	
	   public void add (T element)
	   {      
		   LinearNode<T> node = new LinearNode<T> (element); 
       
		   if (size() == 0) {  
			   	this.last = node; 
			 	this.front = node; 
			 	this.count++;
		   }
		   else
		     { 
				  last.setNext(node); 
				  last = node; 
			     
				  this.count++;   
		      } 
	   }
	   
	
	public T remove()
	   {
		   LinearNode<T> temp = null;
		   T result = null;
			if (isEmpty()) {
				System.out.println("There are no nodes in the list");
			}//end if
			else {
				
				result = this.front.getElement();
				temp = this.front;
				this.front = this.front.getNext();
				temp.setNext(null); //dereference the original first element
				count--;
			}//end else
			return result;

	   }

	  
	   //  Returns true if this list contains no elements
	   public boolean isEmpty()
	   {
		   if (this.front == null)
			   return true;
		   else
			   return false;
	   }


	   //  Returns the number of elements in this list
	   public int size()
	   {
		   return this.count;
	   }

	   //  Returns a string representation of this list
	  


	public String toString()
	   {
		   LinearNode<T> current = null;
		   String fullList = "";
		   
		   for (current = this.front; current != null; current = current.getNext())
		   {
			   fullList = fullList + "\n" + current.getElement().toString();
		   }//end for
		   
		   return fullList + "\n";
	   }

}



